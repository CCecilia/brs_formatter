from setuptools import setup

setup(name='brs-formatter',
      version='0.1',
      description='Formats brightsript files for Roku development.',
      url='http://github.com/storborg/funniest',
      author='Christian Cecilia',
      author_email='christian@fubo.tv',
      license='MIT',
      packages=[],
      zip_safe=False)